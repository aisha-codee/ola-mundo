nome=input('digite seu nome: \n')
print("seu nome é", nome)


